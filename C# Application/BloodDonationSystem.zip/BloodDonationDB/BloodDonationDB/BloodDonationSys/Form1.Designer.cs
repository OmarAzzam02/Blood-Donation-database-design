﻿
namespace StudentRegSys
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.BirthDate = new System.Windows.Forms.MonthCalendar();
            this.InsertButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DatePick = new System.Windows.Forms.DateTimePicker();
            this.BloodType = new System.Windows.Forms.ComboBox();
            this.TimePick = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Phonetxt = new System.Windows.Forms.TextBox();
            this.Weighttxt = new System.Windows.Forms.TextBox();
            this.HeightTxt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ConDLabel = new System.Windows.Forms.Label();
            this.Contxt = new System.Windows.Forms.TextBox();
            this.Addresstxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.NoButton = new System.Windows.Forms.RadioButton();
            this.YesButton = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.Emailtxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.SSNtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.SearchTxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ViewAllTabPage = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.ViewAllTabPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(863, 542);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Cornsilk;
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.BirthDate);
            this.tabPage1.Controls.Add(this.InsertButton);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(855, 513);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Donor Regestration ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(435, 31);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 20;
            this.label7.Text = "Birth Date";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // BirthDate
            // 
            this.BirthDate.Location = new System.Drawing.Point(425, 56);
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.TabIndex = 4;
            this.BirthDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.BirthDate_DateChanged);
            // 
            // InsertButton
            // 
            this.InsertButton.AutoSize = true;
            this.InsertButton.Location = new System.Drawing.Point(438, 446);
            this.InsertButton.Margin = new System.Windows.Forms.Padding(4);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(129, 32);
            this.InsertButton.TabIndex = 3;
            this.InsertButton.Text = "Insert Record";
            this.InsertButton.UseVisualStyleBackColor = true;
            this.InsertButton.Click += new System.EventHandler(this.InsertButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DatePick);
            this.groupBox1.Controls.Add(this.BloodType);
            this.groupBox1.Controls.Add(this.TimePick);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.Phonetxt);
            this.groupBox1.Controls.Add(this.Weighttxt);
            this.groupBox1.Controls.Add(this.HeightTxt);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.ConDLabel);
            this.groupBox1.Controls.Add(this.Contxt);
            this.groupBox1.Controls.Add(this.Addresstxt);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.NoButton);
            this.groupBox1.Controls.Add(this.YesButton);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Emailtxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Nametxt);
            this.groupBox1.Controls.Add(this.SSNtxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 22);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(395, 482);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic Information";
            // 
            // DatePick
            // 
            this.DatePick.Location = new System.Drawing.Point(3, 454);
            this.DatePick.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DatePick.Name = "DatePick";
            this.DatePick.Size = new System.Drawing.Size(178, 22);
            this.DatePick.TabIndex = 25;
            // 
            // BloodType
            // 
            this.BloodType.FormattingEnabled = true;
            this.BloodType.Items.AddRange(new object[] {
            "A+",
            "A-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.BloodType.Location = new System.Drawing.Point(87, 362);
            this.BloodType.Margin = new System.Windows.Forms.Padding(4);
            this.BloodType.Name = "BloodType";
            this.BloodType.Size = new System.Drawing.Size(192, 24);
            this.BloodType.TabIndex = 1;
            this.BloodType.SelectedIndexChanged += new System.EventHandler(this.BloodType_SelectedIndexChanged);
            // 
            // TimePick
            // 
            this.TimePick.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.TimePick.Location = new System.Drawing.Point(0, 417);
            this.TimePick.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TimePick.Name = "TimePick";
            this.TimePick.Size = new System.Drawing.Size(178, 22);
            this.TimePick.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 370);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "BloodType";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(0, 399);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(168, 16);
            this.label15.TabIndex = 22;
            this.label15.Text = "Pick up you Time and Date";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 70);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 16);
            this.label18.TabIndex = 19;
            this.label18.Text = "Phone";
            // 
            // Phonetxt
            // 
            this.Phonetxt.Location = new System.Drawing.Point(96, 67);
            this.Phonetxt.Margin = new System.Windows.Forms.Padding(4);
            this.Phonetxt.Name = "Phonetxt";
            this.Phonetxt.Size = new System.Drawing.Size(203, 22);
            this.Phonetxt.TabIndex = 18;
            // 
            // Weighttxt
            // 
            this.Weighttxt.Location = new System.Drawing.Point(76, 319);
            this.Weighttxt.Margin = new System.Windows.Forms.Padding(4);
            this.Weighttxt.Multiline = true;
            this.Weighttxt.Name = "Weighttxt";
            this.Weighttxt.Size = new System.Drawing.Size(203, 29);
            this.Weighttxt.TabIndex = 17;
            // 
            // HeightTxt
            // 
            this.HeightTxt.Location = new System.Drawing.Point(76, 283);
            this.HeightTxt.Margin = new System.Windows.Forms.Padding(4);
            this.HeightTxt.Multiline = true;
            this.HeightTxt.Name = "HeightTxt";
            this.HeightTxt.Size = new System.Drawing.Size(203, 28);
            this.HeightTxt.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 293);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 16);
            this.label17.TabIndex = 15;
            this.label17.Text = "Hight";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 332);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 16);
            this.label16.TabIndex = 14;
            this.label16.Text = "Weight";
            // 
            // ConDLabel
            // 
            this.ConDLabel.AutoSize = true;
            this.ConDLabel.Location = new System.Drawing.Point(-3, 259);
            this.ConDLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ConDLabel.Name = "ConDLabel";
            this.ConDLabel.Size = new System.Drawing.Size(76, 16);
            this.ConDLabel.TabIndex = 13;
            this.ConDLabel.Text = "CondName";
            // 
            // Contxt
            // 
            this.Contxt.Location = new System.Drawing.Point(96, 246);
            this.Contxt.Margin = new System.Windows.Forms.Padding(4);
            this.Contxt.Multiline = true;
            this.Contxt.Name = "Contxt";
            this.Contxt.Size = new System.Drawing.Size(203, 29);
            this.Contxt.TabIndex = 12;
            // 
            // Addresstxt
            // 
            this.Addresstxt.Location = new System.Drawing.Point(119, 157);
            this.Addresstxt.Margin = new System.Windows.Forms.Padding(4);
            this.Addresstxt.Multiline = true;
            this.Addresstxt.Name = "Addresstxt";
            this.Addresstxt.Size = new System.Drawing.Size(203, 29);
            this.Addresstxt.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 172);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Address:";
            // 
            // NoButton
            // 
            this.NoButton.AutoSize = true;
            this.NoButton.Location = new System.Drawing.Point(205, 208);
            this.NoButton.Margin = new System.Windows.Forms.Padding(4);
            this.NoButton.Name = "NoButton";
            this.NoButton.Size = new System.Drawing.Size(46, 20);
            this.NoButton.TabIndex = 10;
            this.NoButton.Text = "No";
            this.NoButton.UseVisualStyleBackColor = true;
            this.NoButton.CheckedChanged += new System.EventHandler(this.NoButton_CheckedChanged);
            // 
            // YesButton
            // 
            this.YesButton.AutoSize = true;
            this.YesButton.Location = new System.Drawing.Point(119, 208);
            this.YesButton.Margin = new System.Windows.Forms.Padding(4);
            this.YesButton.Name = "YesButton";
            this.YesButton.Size = new System.Drawing.Size(52, 20);
            this.YesButton.TabIndex = 9;
            this.YesButton.Text = "Yes";
            this.YesButton.UseVisualStyleBackColor = true;
            this.YesButton.CheckedChanged += new System.EventHandler(this.YesButton_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 212);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Medical cond";
            // 
            // Emailtxt
            // 
            this.Emailtxt.Location = new System.Drawing.Point(119, 127);
            this.Emailtxt.Margin = new System.Windows.Forms.Padding(4);
            this.Emailtxt.Name = "Emailtxt";
            this.Emailtxt.Size = new System.Drawing.Size(203, 22);
            this.Emailtxt.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 135);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Email:";
            // 
            // Nametxt
            // 
            this.Nametxt.Location = new System.Drawing.Point(96, 97);
            this.Nametxt.Margin = new System.Windows.Forms.Padding(4);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(203, 22);
            this.Nametxt.TabIndex = 5;
            // 
            // SSNtxt
            // 
            this.SSNtxt.Location = new System.Drawing.Point(96, 35);
            this.SSNtxt.Margin = new System.Windows.Forms.Padding(4);
            this.SSNtxt.Name = "SSNtxt";
            this.SSNtxt.Size = new System.Drawing.Size(132, 22);
            this.SSNtxt.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 103);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "DonorID";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Lavender;
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.SearchBtn);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.SearchTxt);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(855, 513);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Search And Update ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 212);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(844, 293);
            this.dataGridView1.TabIndex = 10;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // SearchBtn
            // 
            this.SearchBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.SearchBtn.Location = new System.Drawing.Point(319, 30);
            this.SearchBtn.Margin = new System.Windows.Forms.Padding(4);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(100, 28);
            this.SearchBtn.TabIndex = 9;
            this.SearchBtn.Text = "Retrieve";
            this.SearchBtn.UseVisualStyleBackColor = false;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::StudentRegSys.Properties.Resources.Services;
            this.pictureBox2.Location = new System.Drawing.Point(672, 18);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(152, 139);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // SearchTxt
            // 
            this.SearchTxt.Location = new System.Drawing.Point(158, 32);
            this.SearchTxt.Margin = new System.Windows.Forms.Padding(4);
            this.SearchTxt.Name = "SearchTxt";
            this.SearchTxt.Size = new System.Drawing.Size(132, 22);
            this.SearchTxt.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(41, 35);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 16);
            this.label14.TabIndex = 0;
            this.label14.Text = "Enter BloodType";
            // 
            // ViewAllTabPage
            // 
            this.ViewAllTabPage.BackColor = System.Drawing.Color.MintCream;
            this.ViewAllTabPage.Location = new System.Drawing.Point(4, 25);
            this.ViewAllTabPage.Margin = new System.Windows.Forms.Padding(4);
            this.ViewAllTabPage.Name = "ViewAllTabPage";
            this.ViewAllTabPage.Size = new System.Drawing.Size(855, 513);
            this.ViewAllTabPage.TabIndex = 2;
            this.ViewAllTabPage.Text = "View Donors";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 542);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Donor Regestration";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage ViewAllTabPage;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Emailtxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox SSNtxt;
        private System.Windows.Forms.RadioButton YesButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Addresstxt;
        private System.Windows.Forms.Button InsertButton;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox SearchTxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.TextBox Contxt;
        private System.Windows.Forms.Label ConDLabel;
        private System.Windows.Forms.MonthCalendar BirthDate;
        private System.Windows.Forms.TextBox Weighttxt;
        private System.Windows.Forms.TextBox HeightTxt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox Phonetxt;
        private System.Windows.Forms.RadioButton NoButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker DatePick;
        private System.Windows.Forms.DateTimePicker TimePick;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox BloodType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

